# Candidate profile — FILL THIS IN BEFORE THE FIRST RUN

Everything jobSearch filters and ranks on lives in this file. Replace every `[FILL IN]`
below. Delete the instruction lines in italics once you've answered them — they're here to
explain what a good answer looks like, not to stay in the file.

---

## Identity

- **Name:** [FILL IN]
- **Based in:** [FILL IN — city, state]
- **Timezone:** [FILL IN — used for validation timestamps]
- **Years of experience:** [FILL IN]
- **Education:** [FILL IN — degree, field, school, year]

## Target roles — ranked by fit

*List the role families you'd actually accept, best fit first. Use real job titles, not
aspirations. Group them into families so a search can run each one as its own query.*

1. **[FAMILY NAME]:** [FILL IN — e.g. "Analytics Manager, Data & Analytics Lead, BI Manager"]
2. **[FAMILY NAME]:** [FILL IN]
3. **[FAMILY NAME]:** [FILL IN]

### Families that are genuinely in scope but look like a step sideways

*This section prevents the most common search failure: silently filtering out a whole job
family because its titles don't match your self-description. If you'd take an IC role as
well as a manager role, or a role in an adjacent function, say so explicitly here and say
why you're competitive for it — otherwise runs will quietly drop them.*

[FILL IN, or write "none" — e.g. "Customer Success is a first-class target, not a fallback.
My earlier customer-facing technical enablement years cover the IC track and my management
years cover the manager track. Do not filter either one out, and do not treat a CSM title
as a step down."]

## Employer vocabulary — search THEIR words, not mine

*Job titles rarely use your self-description. List the terms employers use for work you can
do, even when they share no keyword with your primary vocabulary. Add to this list whenever
a run surfaces a new title family.*

[FILL IN — e.g. "customer success, technical adoption, technical account, technical success,
adoption specialist, enablement, onboarding, customer operations, GTM operations, revenue
operations, business operations, insights, program management, data platform"]

## Key skills for JD matching

- **Languages / query:** [FILL IN]
- **Platforms / tools:** [FILL IN]
- **Visualization:** [FILL IN]
- **Methodology:** [FILL IN]
- **Domain / differentiators:** [FILL IN — the cross-domain background that makes you an
  interesting candidate rather than an interchangeable one]

## Filters

- **Onsite/hybrid metro(s):** [FILL IN — list the specific cities/suburbs you'd commute to]
- **Remote in scope?** [FILL IN — yes/no; if yes, which countries or regions]
- **Anything else is out of scope:** yes (change only if you'd relocate)
- **Recency window:** [FILL IN — days; 14 is a good default]
- **Salary floor:** [FILL IN — USD; roles with a posted ceiling below this are excluded]
- **Employment type:** [FILL IN — full-time / contract / either]
- **Hard exclusions:** [FILL IN — industries, companies, or conditions that are automatic
  no's, e.g. "no commission-only", "no on-site more than 3 days", "no defense"]

## Priority employers — checked first on every single run

*These get their careers site checked directly, every run, before any aggregator. Five to
ten is the right size. Include the ATS URL pattern where you know it, so runs don't have to
rediscover it.*

| Employer | Careers site / ATS URL | Why it's a priority |
|---|---|---|
| [FILL IN] | [FILL IN] | [FILL IN] |
| [FILL IN] | [FILL IN] | [FILL IN] |
| [FILL IN] | [FILL IN] | [FILL IN] |

### Secondary employers in the metro — add as results warrant

[FILL IN — a list of large local employers worth sweeping when the priority list is thin]

## Output location

- **Save spreadsheets to:** [FILL IN — an absolute folder path on your machine, or write
  "outputs folder" to leave them in the session outputs]

## Notes for the searcher

*Anything a recruiter would want to know that doesn't fit above — visa status, notice
period, a title you've outgrown, a company you already applied to and were rejected by.*

[FILL IN, or delete this section]

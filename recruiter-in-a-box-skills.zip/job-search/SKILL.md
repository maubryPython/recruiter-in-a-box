---
name: job-search
description: "Web-scraping recruiter that finds active, link-validated job postings the candidate is competitive for. Trigger on \"Use jobSearch to find [N] jobs to apply for\", or any request to find jobs, search job boards, check LinkedIn/Indeed/ZipRecruiter/state workforce boards, check openings at a named employer, or ask \"what should I apply for\". Target roles, location, recency and salary floor come from references/candidate-profile.md. Every recommendation is link-validated on the employer's own careers site before delivery, and the apply link delivered is always the employer's URL — never an aggregator. Hands off any recommended job to the resume-create skill on request (\"prepare a resume for #2\")."
---

# jobSearch — validated job hunting

Find active, high-fit job postings the candidate can apply to today. The starting prompt is "Use jobSearch to find [N] jobs to apply for" — parse N; if absent, default to 5. Deliver N *validated* jobs, which means searching a wider funnel (roughly 2–3x N candidates) because some will fail validation.

## FIRST RUN — set up the profile

All candidate-specific information lives in **`references/candidate-profile.md`**. Read it at the start of every run.

If that file still contains the `[FILL IN]` placeholders, stop and walk the candidate through filling it out before searching — use AskUserQuestion to collect target roles, location and commute tolerance, salary floor, priority employers, and recency window, then write their answers into the file. A search run against an unfilled profile produces noise.

If the resume-create skill is also installed, its `references/master-resume.md` is the deeper source for fit assessment on a specific posting. Never claim experience not traceable to it.

## Default filters

Read these from `references/candidate-profile.md`:

- **Location** — the metro areas acceptable for onsite/hybrid, plus whether 100% remote is in scope. Nothing else.
- **Recency** — posted within the last N days (14 is a good default).
- **Salary** — bias heavily toward posted ranges above the candidate's floor. Include strong-fit roles with no posted salary, ranked lower and flagged "salary not posted." Exclude roles with posted ceilings below the floor.
- **Type** — full-time unless told otherwise.

Any of these can be overridden in the prompt ("...remote only", "...last 7 days", "...at a specific employer").

## THE APPLY-LINK RULE — read before anything else

**Every delivered job must carry an apply link on a domain the employer controls. An aggregator link in the Primary Apply URL field is a defect, not a fallback.**

Aggregators are a *discovery* tool only. Finding a job on Indeed tells you the job may exist; it does not give you a link the candidate can apply through, and it does not confirm the req is live. Those are separate things, and conflating them is the single most common failure mode of this skill. A run that found five great-looking jobs and delivered five `to.indeed.com` links delivered nothing.

**Employer-controlled domains — acceptable in Primary Apply URL:**

- The company's own site: `company.com/careers/...`, `careers.company.com/...`, `jobs.company.com/...`
- An ATS instance scoped to that one employer:
  - Workday — `{tenant}.wd{N}.myworkdayjobs.com/...`
  - Lever — `jobs.lever.co/{company}/...`
  - Greenhouse — `boards.greenhouse.io/{company}/...` or `job-boards.greenhouse.io/{company}/...`
  - iCIMS — `careers-{company}.icims.com/...` or `{company}.icims.com/...`
  - SmartRecruiters — `jobs.smartrecruiters.com/{Company}/...`
  - Ashby — `jobs.ashbyhq.com/{company}/...`
  - Workable — `apply.workable.com/{company}/...`
  - Taleo, SuccessFactors, Phenom, Eightfold and similar instances carrying the employer's name or tenant ID
  - Google's careers portal — `google.com/about/careers/applications/jobs/results/...`

**Never acceptable in Primary Apply URL — this list is not exhaustive, the test is "does the employer control this domain":**

`indeed.com` · `to.indeed.com` · `linkedin.com` · `ziprecruiter.com` · `glassdoor.com` · `builtin.com` · `themuse.com` · `simplyhired.com` · `lensa.com` · `talent.com` · `jobright.ai` · `tealhq.com` · `theladders.com` · `remoterocketship.com` · `jobleads.com` · `dice.com` · `zippia.com` · `flexjobs.com` · `simplify.jobs` · `remotive.com` · `career.com` · university and government job boards mirroring the posting · any other third-party board or scraper mirror.

**If no employer-controlled apply URL can be found and fetched, the job is NOT deliverable.** Do not deliver it with an aggregator link substituted. Do not deliver it with the field blank. Drop it, and list it under "Filtered out" with the reason "no employer apply link could be validated." Deliver fewer jobs and say why — that is explicitly better than delivering an unusable link.

The aggregator link still has a home: the **Job Posting URL** column, which records where the job was discovered. That column may contain an Indeed or LinkedIn URL. The Primary Apply URL column may not. Keep them straight — never copy one into the other.

### Finding the employer URL when the careers site won't render

This is the actual work, and it is where the skill earns its keep. Most enterprise careers sites (Workday, Phenom, iCIMS, Eightfold) are client-rendered: a plain fetch returns an empty HTML shell or a template with unexpanded placeholders like `${pageStateData.searchKeyword}`. That shell is **not** evidence the job is missing, and it is **not** grounds to fall back to an aggregator. Escalate through these, in order:

1. **A real browser (Claude in Chrome, or the in-app browser)** — the primary tool, not a fallback. It renders JavaScript and shows true posted dates. Check whether one is available at the start of every run.
2. **The employer's ATS search URL with query parameters.** Workday accepts `?q=`: `https://{tenant}.wd{N}.myworkdayjobs.com/en-US/{site}?q={terms}` or `?q={reqID}`. Lever, Greenhouse and Ashby board roots are usually server-rendered and fetch cleanly — fetch the board root and search the returned text for the title.
3. **Search engines scoped to the employer's domain.** `site:careers.company.com "Job Title"` or a plain search including the ATS hostname often surfaces the real deep link, which you then fetch to confirm.
4. **Aggregator mirrors as a source of the employer URL, never as the link itself.** Some mirrors expose the full underlying `myworkdayjobs.com` or `greenhouse.io` path in their apply button or page body. Harvest that URL, fetch it, confirm it, deliver it. The mirror's own URL stays out of the apply column.
5. **Req-ID search URL as the documented fallback.** `https://{tenant}.wd{N}.myworkdayjobs.com/en-US/{site}?q={ReqID}` resolves to exactly that one posting. This is a legitimate employer-controlled link, one click from the posting, and must be labeled in Validation Status as a req-filtered search rather than a deep link.

**Do not hand-construct `/job/{slug}_{ReqID}` URLs.** The slug is internal and unguessable; multi-location reqs insert a location segment that varies. Six consecutive constructed URLs 404'd in one session while the req-ID search URL worked first time. If the deep link isn't already in hand from a real source, go straight to option 5.

If steps 1–5 all fail for a given job, that job is not deliverable. Say so plainly and move to the next candidate in the funnel.

## Sources — employer sites FIRST, aggregators second

**Search engines and aggregators cannot see the freshest postings.** A req published in the last few days is usually not yet indexed, and aggregator mirrors (Indeed, Built In, Glassdoor, the Muse) lag by days to weeks. Since the recency filter is typically 14 days, a search-engine-first method is structurally blind in exactly the window that matters most. This has produced real misses: a manager-level req posted the previous day was invisible to `site:` queries, req-ID probes, and every aggregator — but sat plainly on the employer's own careers page.

Order of operations:

1. **Priority employer careers sites — always first, every run.** The employers named in `candidate-profile.md`, every time; add other employers in the target metro as results warrant. These sites show true posted dates ("Posted Today", "Posted 2 Days Ago") that no aggregator reproduces reliably.
2. **Indeed MCP or equivalent** — if a `search_jobs` tool is connected, use it to widen beyond the named employers. Treat its post dates as unverified, and treat every result as a *lead requiring an employer URL* before it can be delivered.
3. **Web search** — LinkedIn, ZipRecruiter, and the state workforce board (e.g. worksourceoregon.org) via site-scoped queries. Useful for discovery, unreliable for recency, never a source of apply links.

**Budget the run accordingly.** Converting a lead into a deliverable job takes several calls: find the employer URL, fetch it, soft-404 scan it, confirm the posted date. Plan for that up front rather than discovering at the end that four of five finalists have no employer link. When a lead resists after two or three attempts, drop it and move on — there are more leads in the funnel.

### Querying Workday career sites (most enterprises)

Workday search pages are JavaScript-rendered — a plain fetch returns an empty shell — but they accept URL query parameters, and a real browser can read the rendered result:

- Keyword search: `https://{tenant}.wd{N}.myworkdayjobs.com/en-US/{site}?q={terms}`
- Isolate one req: `?q={reqID}` returns exactly that job, with its true posted date.
- The bare site root lists everything newest-first — good for a "what dropped today" pass.

Some careers sites (Phenom-based ones in particular) filter only via client-side interaction; URL keyword parameters are ignored and encoded filter URLs may be refused. Reading the unfiltered page still yields career-area counts (e.g. "Data 5"), which is useful for gauging pipeline depth.

### Search the employer's vocabulary, not just the candidate's

Job titles rarely use the candidate's self-description. In one real case, searching only "analytics manager", "data governance", and "master data" missed an entire Technical Adoption job family at a priority employer — customer-enablement leadership roles that were a strong fit but shared no keyword with the query.

For each target employer, run the role families in **their** language as well as the candidate's. `candidate-profile.md` carries an "employer vocabulary" list for this; extend it whenever a run turns up a new title family. Run the full list on every pass — the terms that share no keyword with the candidate's primary vocabulary are exactly the ones that stay invisible otherwise.

**When the candidate adds a new criterion mid-search, re-run it against the named priority employers**, not only against generic aggregators. A criterion added late is still a criterion.

## Validation — the non-negotiable step

A dead link wastes the candidate's time and credibility. So does a link they can't apply through. For every job you intend to recommend:

1. **Obtain the employer-controlled apply URL** per the Apply-Link Rule above. No employer URL, no delivery. Do this *before* spending effort on the rest of validation — it is the step most likely to disqualify a lead, so failing fast here saves the most time.
2. **Fetch that employer URL.** If it 404s, redirects to a generic search page, or shows "no longer accepting applications" / "position filled," discard it.
3. **Scan the fetched body for soft-404s.** Career sites often return HTTP 200 with normal navigation and branding while the page body says the job is gone. Search the fetched text (case-insensitive) for markers like: "404", "can't find the page", "page not found", "no longer available", "no longer accepting", "position has been filled", "job has expired", "posting has closed", "search all jobs". Any hit means the posting is dead — discard it, no matter how complete the rest of the page looks. This has happened in practice: a posting fetched with a full job description was actually serving "404 — We can't find the page you are looking for" to a human visitor.
4. **A live job description on an aggregator proves nothing about the req.** Aggregator detail endpoints happily return complete, current-looking JDs for reqs that have been pulled, and their content is a scrape of unknown age. It is useful for assessing fit and reading requirements; it is not evidence the posting is open. Only the employer's page settles that.
5. **Beware cached or stale renders.** A fetch can return archived job content for a posting that has since been pulled. Treat a fetched JD as evidence, not proof. Corroborating signals that a posting is truly live: it appears in the company's own careers-site search results *today*, the apply endpoint loads, or the employer page shows a recent posted date. A posting with no displayed posted date plus any other oddity (e.g. an `#LI-DNI` tag, "employer will accept" PERM-style wording) deserves extra suspicion.
6. **Aggregator dates lie in BOTH directions — never discard a job on an aggregator's post date alone.** Rule 3 catches dead jobs that look alive; the opposite failure is just as costly. A req showing a five-month-old date on Indeed — and written off as stale — was showing "Posted 2 Days Ago" on the employer's own careers site the same day. Writing it off nearly cost a perfect-title match at a priority employer. Before discarding any strong-fit posting as too old, check the employer's own site for its real date. Aggregator dates can reflect first-seen, re-scrape, or repost events rather than the true current posting date.
7. **Prefer the employer's posted date** over the aggregator's in the delivered output. When only the aggregator date is available, label it as such in Validation Status.
8. **Re-validate immediately before delivery.** If more than a few minutes passed between validation and building the final output, re-fetch each recommended employer URL once more with the soft-404 scan. Postings can die mid-session.
9. If a posting cannot be confirmed on the employer's own site, it is not deliverable. There is no "flag it and ship it anyway" path for the apply link — a caveat in a spreadsheet cell does not make an Indeed URL applicable.

**Use a real browser as the FIRST tool for employer careers sites, not a fallback.** Most enterprise employers render their search pages client-side, so a plain fetch returns an empty shell and search engines lag days behind. The browser is the only way to see true posted dates. Check for browser access at the start of a run; if Claude in Chrome isn't connected, say so up front, give the install link (https://chromewebstore.google.com/detail/fcoeoabgfenejglbffodgkkbkcdhcgfn), and note that installing is not enough — the Claude side panel must be open and signed in to the same account. Base URLs are approved more readily than URLs carrying encoded query parameters; if a navigation is refused, retry the bare domain first.

**Without a browser, say so at the START of the run, not only at the end.** Warn the candidate that coverage of client-rendered employers will be thin and that some strong leads may have to be dropped for lack of a validated apply link. Then hold the line on the Apply-Link Rule anyway — a shorter honest list beats a padded unusable one.

Record the timestamp (in the candidate's timezone) when each job was validated.

## Ranking

Order results by: (1) posted salary above the floor, (2) role fit against the candidate profile, (3) recency, (4) priority-employer bonus. Salary-not-posted roles rank below comparable posted-salary roles.

## Output

Deliver both a chat summary and a saved spreadsheet.

**Chat:** a compact table — Job Title, Company, Salary, Posted date, one-line "why you're competitive." The Job Title must hyperlink to the **Primary Apply URL** — the validated, employer-controlled application link. Never link a chat title to an aggregator; if that is the only link available, the job should not be in the table at all. The point of the chat link is one click to apply. Follow the table with any jobs that failed validation, including any dropped specifically for lack of an employer apply link, so the candidate knows what was filtered out and why.

**Spreadsheet:** use the xlsx skill. File name `JobSearch_Results_[YYYY_MM_DD].xlsx`, saved to the output folder named in `candidate-profile.md` if accessible, otherwise the outputs folder. One row per job, columns in exactly this order:

| # | Column | Content |
|---|---|---|
| 1 | Rank | 1 = best match |
| 2 | Job Title | Exact title from posting |
| 3 | Company | Employer name |
| 4 | Primary Apply URL | **Employer-controlled application link ONLY** — the company's own careers site or its scoped ATS instance. Never an aggregator. If none could be validated, the job does not appear in this sheet. |
| 5 | Salary Range | Posted range, or "Not posted" |
| 6 | Posted Date | From the employer's posting where available; note if the date came from an aggregator |
| 7 | Company Description | One sentence on what the company does |
| 8 | Company Website | Company homepage URL |
| 9 | Job Posting URL | Where the job was discovered — this is the column where an Indeed/LinkedIn URL belongs, if that's where it was found. If discovery and application were the same employer page, repeat that URL here. |
| 10 | Location / Mode | City + onsite/hybrid/remote |
| 11 | Sourced Timestamp | When it was validated (candidate's timezone) |
| 12 | Why Competitive | 1–2 sentences mapping the candidate's record to the JD |
| 13 | Validation Status | How the employer page was confirmed — e.g. "Verified at primary source (deep link fetched, no soft-404 markers)" or "Verified via req-filtered search URL, req R54135" — plus any remaining caveat about posted date or fit |

Before saving, **audit column 4 across every row**: each cell must be a URL on an employer-controlled domain per the Apply-Link Rule. If any row fails, fix it or remove the row. This check is cheap and catches the failure mode this column exists to prevent.

All URL cells (Primary Apply URL, Company Website, Job Posting URL) must be written as live, clickable hyperlinks — not plain text. In openpyxl set both the display value and `cell.hyperlink = url`, and style the cell like a link (blue font, underline) so the candidate can click straight through from Excel. If a cell needs a note alongside the link (e.g. "search req 26WD98646"), put the note in the Validation Status column — never append text to the URL itself, or the link breaks.

## After delivering

Offer next steps in one line: tailor a resume for any listed job via resumeCreate (see below), or schedule this search to run automatically (e.g. weekday mornings).

## resumeCreate handoff — tailor a resume for a recommended job

When the candidate asks for a resume for any recommendation — by rank ("prepare a resume for #2"), by company ("run resumeCreate for the Acme job"), or any similar phrasing — execute the resume-create skill for that job. Don't just suggest it; do it:

1. **Gather the full job description.** Re-fetch the validated employer posting URL and extract the complete JD text (responsibilities, qualifications, tools). If the posting is JS-rendered and unfetchable, use browser tools if available; otherwise ask the candidate to paste the JD — resume-create requires it, and tailoring without it is wasted effort.
2. **Invoke the resume-create skill** with the target position, company, and the JD gathered in step 1. Follow its full playbook: read its references, classify the role, ask its clarifying questions, and produce the 2-page .docx with its naming convention.
3. **Carry context across.** Pass along what jobSearch already knows — the "Why Competitive" mapping, salary range, location/mode, and any validation caveats — so the tailoring emphasizes the same strengths the recommendation was based on, and the candidate isn't asked for information jobSearch already has.
4. Multiple jobs may be requested ("resumes for #1 and #4") — run the handoff for each, one at a time, confirming each JD before drafting.

## Working with the candidate during the run

Don't disappear for twenty tool calls and return with a finished list. Surface candidates as they're found, with a fit read and a freshness read, and let the candidate triage before spending validation effort on them. They know in seconds whether a role is worth chasing; validation is expensive and irreversible time. A short check-in mid-run — "here are six leads, which should I validate?" — consistently beats a polished list built on wrong assumptions.

When they reject a batch, ask what specifically missed (level, domain, comp, location, staleness) and re-run with that. Don't infer it.

## Never do

- **Never put an aggregator URL in the Primary Apply URL column, or behind a chat table's job-title link.** Indeed, LinkedIn, ZipRecruiter, Built In, Glassdoor, the Muse, Lensa, Talent.com, Teal, Jobright, the Ladders and every other third-party board are discovery tools. The apply link is always the employer's.
- Never deliver a job whose employer apply link could not be found and fetched — drop it and say why.
- Never deliver a link you didn't fetch and confirm live this session — including passing the soft-404 body scan, not just a successful HTTP fetch.
- Never treat a live job description on an aggregator as proof that the req is open.
- Never invent postings, salaries, posted dates, or company facts — if a field is unknown, say so.
- Never claim the candidate has experience not supported by the resume-create source material.
- Never pad results with poor-fit jobs to hit N; deliver fewer and say why.
- **Never report tool silence as a market condition.** "I found nothing" means the sources searched returned nothing — not that the market is quiet. Stating "the senior-analytics market is thin this week" turned out to be flatly wrong in one session: a single priority employer had 107 live analytics postings, including three manager-level reqs, all invisible to the method being used. If coverage was incomplete — no browser access, index lag, keyword-only searching — say *that*, and say which sources were actually checked. Distinguish "the indexed sources are quiet" from "the market is quiet," and never let the second claim ride on evidence for the first.
- Never discard a strong-fit posting on an aggregator's post date without checking the employer's own site first.

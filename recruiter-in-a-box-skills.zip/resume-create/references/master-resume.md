# Master resume — the bullet pool

**This is not a resume.** It is the complete, uncut record of every role, every
accomplishment, and every metric. Tailored resumes are cut *from* this file; nothing is ever
written into a resume that isn't already here.

Fill it in once, then maintain it. It is allowed — encouraged — to run many pages. Length
here costs nothing and saves a fabrication later.

---

## How to fill this in

Work backwards from the current or most recent role. For each one capture:

- Exact job title as it appeared on the offer letter or HR record
- Employer, city, state
- Start and end dates as `Month YYYY`
- One line on what the employer does, plus size signals (headcount, revenue) for the
  employers a reader won't recognize
- **Every** accomplishment bullet you can recall, each in the shape:
  *action verb → what you did → scope or scale → measurable outcome*

Good bullets carry a number. "Built dashboards for leadership" is not usable; "Published
Power BI dashboards on Snowflake measuring operational output, used weekly by four division
leads" is. If you don't remember the number, write the bullet anyway and mark it `[metric?]`
so a later pass can chase it.

Record promotions as separate role entries, not as one entry with a date range. The patterns
file can collapse them later; it cannot un-collapse what was never captured.

Keep the bullets you think are irrelevant. The whole point of a pool is that a future JD makes
an old bullet relevant again.

---

## Contact and identity

- **Full name:** [FILL IN]
- **City, State:** [FILL IN]
- **Phone:** [FILL IN]
- **Email:** [FILL IN]
- **LinkedIn:** [FILL IN]
- **Portfolio / GitHub / personal site:** [FILL IN, or delete]

---

## Professional experience

### [EMPLOYER NAME], [City, State] · [Month YYYY] – [Month YYYY]

*[One sentence on what the employer does. Add headcount and revenue if the name isn't
self-explanatory — it gives a reader scale without you claiming anything.]*

#### [Exact Job Title], [Month YYYY] – [Month YYYY]

- [FILL IN — accomplishment with scope and outcome]
- [FILL IN]
- [FILL IN]
- [FILL IN]

#### [Exact Job Title], [Month YYYY] – [Month YYYY]

- [FILL IN]
- [FILL IN]

*[Repeat a `####` block for every title held at this employer, newest first. Repeat the
whole `###` employer block for every employer, newest first.]*

---

### Earlier career

*[Roles old enough or short enough that they'll be compressed to one line on any resume.
Capture them with enough substance that a tailoring pass can pick one up if a JD calls for
it — title, employer, location, years, and the one thing that role proves about you.]*

- **[Title]** — [Employer], [City, State] ([YYYY]–[YYYY]). [FILL IN — the one accomplishment
  worth keeping.]
- **[Title]** — [Employer], [City, State] ([YYYY]–[YYYY]). [FILL IN]

---

## Selected projects

*[Side projects, proofs of concept, open-source work, volunteer builds. Each one: name, the
stack, the date, what it did, what the result showed, and a link if there is one. These are
frequently the strongest differentiator on a resume, especially when they demonstrate a skill
your job history doesn't cover.]*

### [Project name]

[Stack · tools] | [Month YYYY]. [FILL IN — what you built, what it showed, the numbers.]
Repo/link: [FILL IN, or delete]

---

## Education

- [Degree], [Field] — [Institution], [Month YYYY]
- [Additional degree or program, or delete]

## Certifications

- [FILL IN, or write "none"]

## Awards and recognition

*[Internal awards, quota club, published work, speaking slots, patents. These are cheap to
list and read as third-party validation.]*

- [FILL IN, or delete this section]

---

## Gaps and open questions

*[Maintained over time. When a tailoring run hits a posting keyword with no backing here,
it gets logged in this section — that's the interview-prep list, and it's also the to-do
list for improving this file. Delete an entry once the real experience has been written into
the right role above.]*

- [e.g. "Postings keep asking for Looker — never used it, only Power BI and Tableau."]

# Patterns and tailoring playbook

Two reusable condensed entries plus the decision rules for tailoring. Use these in
combination with `master-resume.md`, `profile-defaults.md` and `two-page-layout.md`.

Both patterns below are **authored once at setup** and then reused verbatim (or close to it)
on every run that calls for them. Writing them once, carefully, is what keeps tailored
resumes consistent instead of re-derived from scratch each time.

---

## Pattern A — the combined promotion-path entry

**When to use it:** the target role is outside the candidate's primary discipline (see
`profile-defaults.md`). Collapsing several same-employer roles in that discipline into one
promotion-path entry conserves space and emphasizes trajectory, freeing room for the earlier
roles that match this JD better.

**Shape to fill in at setup:**

> **[Earliest Title] → [Next Title] → [Next Title] → [Current Title]** | [Employer] | [City, ST]
> [Month YYYY] – [Month YYYY]
>
> [One sentence: promotion count, scope of what was led, and the size signal for the employer.]
>
> - [A bullet that rolls up the strongest outcome across all the collapsed roles.]
> - [A second roll-up bullet covering the other half — leadership, or publishing, or scale.]

**Authored version for this candidate:**

[FILL IN at setup — write the actual block, with real titles, dates and numbers pulled from
`master-resume.md`. Keep it to three or four lines of body text.]

Re-word the bullets to mirror the JD where appropriate, but keep every claim traceable to
`master-resume.md`.

---

## Pattern B — the condensed secondary era

**When to use it:** by default, for the earlier era that's rich in stories most modern JDs
don't need — field engineering, fabrication projects, conference speaking, community building,
technical evangelism, early sales engineering. Most JDs only need the headline.

**Shape to fill in at setup:**

> **[Title], [Month YYYY] – [Month YYYY]**
>
> - [The headline outcome, with its biggest number.]
> - [The project or program roll-up — name two or three marquee items in one bullet.]
> - [The speaking, teaching, mentoring or community bullet.]

**Authored version for this candidate:**

[FILL IN at setup — three bullets, drawn from the individual project bullets that live in
`master-resume.md`.]

**Expand into the individual project bullets** (which live in `master-resume.md`) only when
the JD signals the domain directly.

**JD signals that justify expanding:** [FILL IN at setup — e.g. "fabrication, hardware,
community building, developer relations, technical evangelism, hands-on engineering"]

---

## Tailoring playbook

> **Template check first.** Ask whether the candidate wants the human-readable 2-page
> version, the ATS keyword version (`ats-keyword-template.md`), or both. The flow below is
> the human-readable path. On an ATS run, `ats-keyword-template.md` governs headline, skills,
> bullet wording, formatting, and experience-block structure, and overrides anything here or
> in `two-page-layout.md` that conflicts — including Pattern A's collapsing, which costs
> searchable title strings.

### Default flow for "I am applying for [X] at [Y]" requests

1. Start from the 2-page layout in `two-page-layout.md`.
2. Read the JD; identify the four to six strongest keyword themes (skills, tools, domains,
   scope verbs).
3. Decide pattern fit:
   - **In the primary discipline** → keep those roles broken out individually.
   - **Outside it** → collapse to Pattern A and reclaim the space for the earlier roles that
     match this JD.
4. Decide secondary-era depth: Pattern B by default; expand individual projects only on the
   JD signals listed above.
5. Re-word bullets to mirror the JD's verbs and metrics while staying true to the master
   record. Don't invent — every claim must be traceable to `master-resume.md`.
6. Prune the skills block (from the inventory in `profile-defaults.md`) to what the JD or its
   adjacent context will actually scan for. Keep one or two cross-domain skills as
   differentiators.

### Clarifying questions to ask before drafting

Use the AskUserQuestion tool. Cover at least:

- **IC vs. people-management** — determines whether to lead with team/manager scope or
  technical execution.
- **Themes that matter most in this JD** (2–3) — biases bullet selection.
- **Tools or domains to emphasize or de-emphasize.**
- **Tone** — conservative corporate vs. modern product/tech.
- **Companion deliverables** — cover letter? LinkedIn "About" rewrite?

### When the JD is light or vague

Ask one extra question rather than guessing. Common gaps: industry, team size, what success in
this role looks like, whether the role is greenfield or rebuilding something existing.

### Output norms

See `profile-defaults.md` for file naming, save location, format and page count.

# Profile defaults — contact block, skills inventory, conventions

Filled in once at setup alongside `master-resume.md`. These are the reusable pieces every
tailored resume starts from: the contact line, the standing profile paragraph, the full skills
inventory to prune from, and the output conventions.

---

## Contact block (compact — for the human-readable template)

```
[Full Name]
[City, ST] · [phone] · [email] · [linkedin.com/in/handle] · [github.com/handle]
```

The ATS template uses pipes or commas instead of middots, and drops the portfolio line if it
isn't relevant to the posting — see `ats-keyword-template.md`.

Never include a full street address.

---

## Standing profile paragraph

*[Two to three sentences. What you are, the cross-domain background that makes you unusual,
and what you're pointed at. Written for a human; the ATS template rewrites it around the
posting's exact title. Avoid adjectives about work ethic — "detail-oriented", "passionate",
"results-driven" — they carry no information and waste the two lines a reader actually reads.]*

[FILL IN]

---

## Full skills inventory — prune from this, never add to it mid-run

*[The complete list, grouped. A tailored resume keeps only the categories the JD touches,
plus one or two cross-domain differentiators. Having the full list here means a tailoring pass
prunes rather than improvises.]*

- **[Category, e.g. AI & Agents]:** [FILL IN]
- **[Category, e.g. Languages]:** [FILL IN]
- **[Category, e.g. Platforms]:** [FILL IN]
- **[Category, e.g. Visualization]:** [FILL IN]
- **[Category, e.g. Methodology]:** [FILL IN]
- **[Category, e.g. Domain / engineering]:** [FILL IN]

**Which categories always stay:** [FILL IN — the one or two differentiator categories that
earn their line even on an unrelated JD, and one sentence on why.]

---

## Primary discipline

*[Names the function your most recent and most detailed roles belong to. `patterns.md` Step 2
uses this to decide whether to break those roles out individually or collapse them into a
single promotion-path entry.]*

- **Primary discipline:** [FILL IN — e.g. "data analytics and analytics leadership"]
- **Role titles that count as in-discipline:** [FILL IN — e.g. "Data Analyst, Sr. Data
  Analyst, Analytics Manager, Data Scientist, Analytics Engineer, BI Lead, Data PM"]
- **Everything else collapses.** Examples of out-of-discipline targets: [FILL IN]

---

## Output conventions

- **File naming:** `[First]_[Last]_Resume_[Company]_[YYYY_MM_DD].docx`
  - Both templates in one run: suffix the ATS file `_ATS` →
    `[First]_[Last]_Resume_[Company]_ATS_[YYYY_MM_DD].docx`
- **Save location:** [FILL IN — absolute folder path on your machine, or write "outputs
  folder"]
- **Output format:** .docx, via the docx skill
- **Page count:** 2 pages, full stop, unless explicitly overridden

# ATS keyword template (the "boring on purpose" resume)

The third template, alongside the default 2-page layout (`two-page-layout.md`) and the
condensed patterns (`patterns.md`). This one is not written for a human reader first. It is
written for the crude boolean search a recruiter or HR coordinator types into an applicant
tracking system, and for the parser that shreds the uploaded file into fields.

**The problem this solves:** qualified candidates get skipped because the search never
surfaced them. The recruiter typed the exact phrase from her own posting. If that phrase isn't
literally in the document, the candidate isn't in the result set — no matter how well
qualified. Synonyms don't match. Better phrasing doesn't match. Only the exact string matches.

So: mirror the posting's own vocabulary back at it, verbatim, in the places the parser indexes.

---

## Step 1 — Extract before you write

Do this extraction **first**, on the posting text itself, and show the candidate the result
before drafting. Never draft from memory of the posting.

### 1a. The exact job title

Copy the job title character-for-character as the posting wrote it. Not a normalized version,
not the industry-standard equivalent, not a tidied-up version.

- Posting says "Sr. Data Analyst II (Go-To-Market)" → that string, exactly.
- Do not write "Senior Data Analyst." Do not write "Data Analyst II."

**When the posting gives two versions of the title, use the requisition title, not the
marketing prose.** Postings routinely open with an expanded headline — "Transform Customer
Success as Manager, Customer Success AECO Americas" — while the requisition itself reads
`Manager, Customer Success`. The requisition title is what's in the ATS record and what she
types. The prose version is copywriting.

Watch the word order too. `Manager, Customer Success` and `Customer Success Manager` are
different searches, and at many companies different seniorities. Match the string she wrote.

This exact title goes in the headline and, when it is defensible, echoed in the summary line.
It is the single highest-value string in the document because it is the first thing typed into
every search.

### 1b. Hard skills

Pull the tools, software, platforms, certifications, standards, and systems. The things that
appear as lists in the posting. These are the searchable atoms.

Examples of the shape (from any field): Epic, Cerner, SQL, Excel, HIPAA, Medicaid, Snowflake,
Power BI, Databricks, dbt, Informatica MDM, Salesforce, Tableau, Python, Jira, Agile, SOX,
CPT coding.

If it is a proper noun or an acronym, it is a hard skill. Capture it.

### 1c. Verb + skill pairs → noun-phrase keywords

The posting writes duties as verb phrases. Recruiters search the **noun phrase**. Convert every
duty into the noun form the recruiter will actually type.

| Posting writes | Recruiter searches |
|---|---|
| "Process prior authorizations" | prior authorization |
| "Verify insurance coverage" | insurance verification |
| "Build and maintain dashboards" | dashboard development |
| "Partner with stakeholders to define KPIs" | KPI definition / stakeholder management |
| "Govern master data across systems" | master data management / data governance |
| "Schedule patient appointments" | patient scheduling |

Rule of thumb: nominalize the verb, keep the object. That is the keyword.

### 1d. Discard the fluff

These are copy/paste filler. Nobody searches for them. They consume line space that keywords
should occupy:

- "fast-paced environment"
- "dynamic team player"
- "growth mindset"
- "wear many hats"
- "self-starter"
- "passion for excellence"
- "thrives in ambiguity"

Cut them. Do not mirror them back. Do not build a bullet around them.

### 1e. Produce the keyword table

Land on **5 to 10 exact phrases**. Not 30 — a keyword stuffed everywhere reads as spam and
dilutes each one. Not 3 — too thin to catch the searches. Present them to the candidate as a
table before drafting:

| # | Exact phrase from posting | Backed by (master-resume.md) | Headline | Skills | Bullet |
|---|---|---|---|---|---|
| 1 | | | ✓ | ✓ | ✓ |

Every phrase must land in at least two of the three placements. The high-value ones land in all
three.

---

## Step 2 — The truth gate (run this before drafting, every time)

For each extracted phrase, classify it against `master-resume.md`:

1. **Direct match** — the candidate has demonstrably done this, and the master record says so.
   Use the posting's exact wording. This is the whole point of the template.
2. **Near match / different vocabulary** — the same work under a different name (e.g. posting
   says "data stewardship," master record says "data governance"). **Stop and ask the
   candidate** whether the two are the same thing before adopting the posting's phrasing. Do
   not decide the equivalence yourself.
3. **No match** — the candidate has not done it. It does not go in the document. Tell them it
   was in the posting and that it's a gap, so they know what the interview will probe. Log it
   in the Gaps section of `master-resume.md`.

### Two failure modes that look like direct matches

Both of these pass a naive keyword check and fail the screening call. Check for them
explicitly.

**The homonym trap.** The same word means different things in different functions. Common pairs
to watch:

- **account** — account *data* (records, entities, corporate hierarchies) vs. account
  *relationships* (owning customers, renewals, revenue). A posting saying "enterprise account
  management" almost always means the second. The string matches; the substance is unrelated.
- **pipeline** — data pipeline vs. sales pipeline
- **portfolio** — product portfolio vs. book of business
- **retention** — data retention vs. revenue retention
- **governance** — data governance vs. program governance
- **adoption** — product adoption metrics vs. owning customer adoption
- **forecasting** — statistical forecasting vs. revenue forecasting
- **migration** — data migration vs. customer platform migration

When a keyword match rests on one of these words, leave it out and say why.

**Candidate-specific homonyms to watch:** [FILL IN at setup — the words that recur in this
candidate's history and mean something different in their target functions. This list is the
single highest-value thing to populate after a couple of real runs.]

**Near-miss metric names.** Metric acronyms that sound interchangeable are not. Gross/Net
Revenue **Retention** is a percentage of revenue kept; **Recurring** revenue is a dollar
amount. Analyzing a metric is not owning it; reporting on churn is not reducing it. When the
candidate says they know a metric, confirm *which* metric and *in what capacity* before putting
the posting's exact name in a bullet — then phrase the bullet to match the capacity
("analyzed," not "owned").

**This gate is absolute.** Keyword optimization is a retrieval problem, not a license to
fabricate. A resume that surfaces in the search and then collapses in the screening call is
worse than one that never surfaced. If a phrase can't be traced to a line in
`master-resume.md`, it does not appear in the resume.

When in doubt: ask. One clarifying question costs thirty seconds. An invented claim costs the
role.

---

## Step 3 — Format: make it boring on purpose

The parser is the reader. Everything that makes a resume look designed makes it parse worse.

**Required:**

- Single column. No side rail, no sidebar, no two-column skills block.
- Black text on white. No accent colors anywhere, including headings.
- One standard serif or sans font throughout — Times New Roman, Arial, Calibri, 10–12pt. No
  font pairing.
- Standard section headings, spelled the standard way: `Summary`, `Skills`,
  `Professional Experience`, `Education`, `Certifications`. Not "Where I've Been." Not "My
  Toolkit." The parser matches on these literal words.
- Plain round bullets. No dashes, no arrows, no custom glyphs.
- Dates as `Month YYYY – Month YYYY` (e.g. `November 2018 – April 2026`). Consistent
  everywhere.
- Contact block: name on its own line, then location, phone, email, LinkedIn URL. Plain
  separators — a pipe or a comma. No middot (·), no icons, no em-dash chains.
- Everything in the document body.

**Forbidden:**

- Tables and text boxes — many parsers read them out of order or drop them entirely.
- Headers and footers — commonly discarded wholesale. Never put contact info there.
- Icons, logos, photos, skill-rating bars, star ratings, graphics of any kind.
- Colored boxes, shading, borders, horizontal rules with color.
- Columns, including a "two column skills" section.
- Text as image.

It should look like it came off a 1995 word processor. That is correct and intentional. Do not
improve it.

---

## Step 4 — The headline (search hook, not a job title)

Directly beneath the name, a single plain-text line: the exact job title from the posting, then
the highest-value hard keywords, pipe-delimited.

**Formula:** `[Exact job title from the posting] | [Keyword] | [Keyword] | [Keyword] | [Keyword]`

**Example of the shape** (illustrative, from a healthcare posting):

> Patient Access Coordinator | Epic | Cerner | Patient Registration | Insurance Verification

**Understand what this line is and isn't.** It is not a claim about the candidate's current or
past title. It is a retrieval hook — the strings that need to be in the document so the search
finds it. Real titles live below, in the job history, unaltered and accurate. Nothing about the
headline is a representation that the candidate held that job; the experience section is the
factual record and it stays factually correct.

Keep it to one line. Four to five items maximum. Every keyword in it must clear the Step 2
truth gate.

---

## Step 5 — Skills: a plain comma list

The skills section is one paragraph of comma-separated hard skills. Nothing else.

**Example of the shape:**

> Epic, Cerner, Patient registration, Insurance verification, Medicaid, Medicare, Prior
> authorization

**Rules:**

- Hard skills only — tools, platforms, systems, certifications, domain nouns.
- **No soft skills.** No "communication," no "teamwork," no "leadership," no "attention to
  detail," no "problem solving." Recruiters do not search for these. They are pure line-waste.
- No proficiency ratings, no years-of-experience annotations, no "expert/intermediate," no bars
  or dots.
- No bolded subcategories (`**Languages:** …`, `**Platforms:** …`). That categorized treatment
  belongs to `two-page-layout.md` and stays there — this template is a flat list.
- Ordered by the posting's priority, not the candidate's. Whatever the posting names first goes
  first.
- Use the posting's spelling. If it writes "Power BI," don't write "PowerBI." If it writes "MS
  Excel," don't write "Microsoft Excel." Match the string.

**Note the deviation:** the standing 2-page template keeps one or two cross-domain skills as the
"interesting candidate" differentiator. That differentiator is a *human-reader* play. In the ATS
template it earns its place only if the posting mentions the domain. Retrieval first; charm in
the interview.

---

## Step 6 — Bullets: the posting's exact language

Rewrite selected bullets from `master-resume.md` so the keyword appears literally.

- Posting says "prior authorization" → bullet says "Processed prior authorizations." Not
  "Handled insurance approvals." Not "Managed pre-certification workflow."
- Posting says "master data management" → bullet says "Led master data management across…" Not
  "Owned enterprise data hygiene."
- Posting says "cross-functional collaboration" → use that string, not "partnered across
  teams."

The bullet's *substance* still comes from `master-resume.md` — the achievement, the scope, the
metric are unchanged and true. Only the vocabulary is swapped to the posting's. If a swap
changes the meaning of the claim rather than just its wording, it fails the truth gate — stop
and ask.

Keep metrics. Numbers survive the parse and they are what a human reads once the search surfaces
the document.

---

## Step 7 — Experience entries: company name on every single role

Application auto-loaders (Workday, Taleo, iCIMS, Greenhouse, Lever) parse each job block
independently and expect a company name inside each one. A grouped company header with several
titles nested beneath it — the shape used in `two-page-layout.md` — reliably produces blank
employer fields for every role but the first, and the candidate then hand-retypes them into the
web form.

**Required shape, one block per role:**

```
Job Title | Company Name | City, State
Month YYYY – Month YYYY
• Bullet
• Bullet
```

So six roles at the same employer each repeat `Employer, Inc. | City, ST`. It looks redundant to
a human. It is correct for the loader. Do not consolidate it.

**Interaction with Pattern A:** Pattern A (`patterns.md`) collapses several same-employer roles
into one promotion-path entry. In the ATS template, collapsing is a keyword cost — each
collapsed title is a title string that no longer matches a search. Default to keeping roles
broken out when their titles contain, or are close to, the posting's exact title. Collapse only
the roles whose titles carry no keyword value for this posting, and only when the 2-page cap
forces it.

---

## Step 8 — Assemble in this order

1. Name
2. Headline (Step 4)
3. Contact line — location, phone, email, LinkedIn
4. Summary — 2–3 plain sentences, working in the exact job title and two or three of the
   keyword phrases. No adjectives about work ethic.
5. Skills (Step 5)
6. Professional Experience (Steps 6–7), reverse chronological
7. Education
8. Certifications, if the posting names any the candidate actually holds

**Length:** 2 pages, same cap as the standing template. If the keyword set won't fit, cut older
bullets — never shrink the font, narrow the margins below 0.5", or spill onto page 3.

---

## Step 8b — Build settings that verified clean

These produced a correctly-parsing two-page document via the docx skill and are a safe starting
point:

- US Letter, `size: { width: 12240, height: 15840 }`; margins 0.5" all sides (`720` DXA).
- Times New Roman, 10.5pt body, 16pt name. One font, no exceptions.
- Job header as a single bold paragraph — `Title | Company | City, ST` — with the date range as
  the plain paragraph directly beneath it.
- Section headings in bold small caps with a black paragraph **bottom border** for the rule.
  Never a one-cell table.
- Bullets via a `numbering` config with `LevelFormat.BULLET` — never a literal `•` character.

After building, convert to PDF and actually look at the pages. Then confirm against the raw XML
that `w:tbl`, `w:txbxContent`, `w:hdr`, `w:ftr`, and `w:drawing` all count zero, and grep the
exact keyword phrases to verify placement counts before delivering.

---

## Step 9 — Pre-delivery checklist

- [ ] The posting's **requisition** job title appears verbatim in the headline, in the posting's
      word order.
- [ ] Homonym check run — no keyword matches on a word that means something different in the
      candidate's history.
- [ ] Metric names verified: right metric, right capacity, verb matches the capacity.
- [ ] 5–10 exact phrases identified; each lands in ≥2 of headline / skills / bullets.
- [ ] Every keyword traces to a line in `master-resume.md`, or was confirmed by the candidate,
      or was dropped.
- [ ] Zero synonym substitutions of the posting's vocabulary.
- [ ] No soft skills anywhere in the skills list.
- [ ] Skills section is a flat comma list, no categories, no ratings.
- [ ] Every role block contains its own company name and location.
- [ ] Single column, black text, one standard font, no tables, no text boxes, no
      headers/footers, no graphics.
- [ ] Standard section headings spelled the standard way.
- [ ] Dates formatted `Month YYYY – Month YYYY` consistently.
- [ ] 2 pages or fewer.
- [ ] Gaps reported — the posting keywords that had no backing and were left out.

---

## Worked example of the shape

Illustrative only. The healthcare content below is invented to demonstrate the format. Real
output always draws its substance from `master-resume.md`.

```
JANE DOE
Patient Access Coordinator | Epic | Cerner | Patient Registration | Insurance Verification
Portland, OR | 503.555.0100 | jane.doe@email.com | linkedin.com/in/janedoe

SUMMARY
Patient Access Coordinator with seven years in hospital patient registration and
insurance verification. Processes prior authorizations for Medicare and Medicaid
populations in Epic and Cerner.

SKILLS
Epic, Cerner, Patient registration, Insurance verification, Medicaid, Medicare,
Prior authorization, HIPAA, Scheduling, Copay collection

PROFESSIONAL EXPERIENCE

Patient Access Representative | Regional Health Partners | Portland, OR
March 2021 – Present
• Completed patient registration for 60+ patients daily in Epic.
• Processed prior authorizations for commercial, Medicare, and Medicaid plans.
• Performed insurance verification prior to scheduled procedures, reducing
  denials by 18%.

EDUCATION
B.S. Health Administration | Portland State University | June 2018
```

Note what it does: exact posting title in the headline, hard skills as a flat comma list,
company name in every role block, posting vocabulary in every bullet, no design, no soft
skills, no fluff.

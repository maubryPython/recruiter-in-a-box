# The 2-page layout (human-readable template)

The default structure for any tailored 2-page resume, unless the JD or the candidate pushes
elsewhere.

> This is the **human-readable** template. If the ATS keyword version was chosen, use
> `ats-keyword-template.md` instead — it overrides this file's categorized skills block, its
> grouped employer header, and its middot-separated contact line, all of which parse poorly in
> applicant tracking systems.

---

## Section order

1. Contact block
2. Profile (2–3 sentences)
3. Technical / core skills (categorized, pruned to the JD)
4. Professional experience (grouped by employer, reverse chronological)
5. Earlier career (compressed to one line per role)
6. Selected project (one, if it earns the space)
7. Education

---

## 1. Contact block (compact)

```
[Full Name]
[City, ST] · [phone] · [email] · [linkedin.com/in/handle] · [github.com/handle]
```

From `profile-defaults.md`. City and state only — never a street address.

## 2. Profile

The standing paragraph from `profile-defaults.md`, adjusted to point at this JD. Two to three
sentences. What the candidate is, the cross-domain background that makes them unusual, and what
they're pointed at. No adjectives about work ethic.

## 3. Technical skills (pruned)

Categorized, bolded category label, comma-separated within each:

```
**[Category]:** item, item, item
**[Category]:** item, item, item
```

Take the categories from the full inventory in `profile-defaults.md` and **drop any category
the JD doesn't touch**. Keep the differentiator categories named in that file even on an
unrelated JD — they're the reason the resume gets pulled out of the pile rather than sorted
into it.

Typical shape: four to six categories, two lines each at most.

## 4. Experience block

Group by employer. One employer header, then a nested block per title held there:

```
### [Employer], [City, ST] · [Month YYYY] – [Month YYYY]

[One sentence on what the employer does. Headcount and revenue if the name isn't
self-explanatory.]

**[Exact Job Title], [Month YYYY] – [Month YYYY]**
- [Bullet: action → scope → outcome, with a number]
- [Bullet]
- [Bullet]

**[Exact Job Title], [Month YYYY] – [Month YYYY]**
- [Bullet]
- [Bullet]
```

Bullet budget, working within the 2-page cap:

- Current or most relevant role: 3–4 bullets
- Next two roles back: 2 bullets each
- Anything older and in-discipline: 1 bullet
- Out-of-discipline older roles: 1 bullet, or collapse into Earlier career

Whether the in-discipline roles stay broken out like this or collapse into a single
promotion-path entry is the Pattern A decision — see `patterns.md`.

## 5. Earlier career (compressed)

One line per role, oldest era:

```
- **[Title]** — [Employer], [City, ST] ([YYYY]–[YYYY]). [The one accomplishment worth keeping.]
```

Four to six of these is normal. They establish range and trajectory without consuming the page.

## 6. Selected project

One project, only if it proves something the job history doesn't:

```
**[Project name].** [Stack · tools] | [Month YYYY]. [What it did, what the result showed,
the numbers.] Repo: [link]
```

Cut this section before cutting an experience bullet that matches the JD.

## 7. Education

```
[Degree], [Field] — [Institution], [Month YYYY]
```

Certifications go here too, when the posting names one the candidate actually holds.

---

## The 2-page cap

Two pages, full stop, unless the candidate explicitly authorizes more. When the content won't
fit, in order: cut the selected project, compress Earlier career, drop a bullet from the oldest
in-discipline role, collapse per Pattern A. Never shrink the font below 10pt, never narrow the
margins below 0.5", never spill onto page 3.

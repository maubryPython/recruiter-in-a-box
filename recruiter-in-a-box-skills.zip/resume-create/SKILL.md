---
name: resume-create
description: "Use this skill whenever the candidate is preparing or tailoring a resume — prompts like \"I am applying for [position] at [company]\", \"tailor my resume\", \"use resumeCreate\", \"prepare a 2-page resume\", \"make an ATS version\", \"keyword-optimize my resume\", or any job description that needs to become a resume. Draws every claim from references/master-resume.md (the candidate's complete job history, filled in once at setup), applies reusable condensing patterns, and offers either a human-readable 2-page layout or a keyword-optimized ATS template that beats the crude boolean searches recruiters actually use. Trigger even when the skill isn't named — any resume tailoring or job application prep invokes it. Also trigger for cover letters or LinkedIn \"About\" rewrites drawing on the same source material."
---

# resumeCreate — resume tailoring

This skill turns a job description into a tailored 2-page resume, drawing from the
candidate's complete work history and applying the right shape for the target role.

## FIRST RUN — set up the master record

Every claim in every resume this skill produces must trace to
**`references/master-resume.md`**. That file ships as an empty scaffold.

If it still contains `[FILL IN]` placeholders, stop and populate it before drafting
anything. Two ways, candidate's choice:

- They paste or attach their existing resume(s) — the longest, most complete version they
  have, plus any older ones. Extract every role and every bullet into the scaffold's
  structure. More is better: the master record is a *bullet pool*, not a resume, and it is
  allowed to be ten pages long.
- They answer questions role by role. Use AskUserQuestion, work backwards from the current
  job, and capture scope numbers and metrics for each.

Also fill in `references/profile-defaults.md` (contact block, skills inventory, education)
on that first pass.

A tailored resume built on an unfilled master record is fabrication. There is no shortcut
past this step.

## Two output templates

**Neither is automatic — ask which one before drafting (Step 0).**

- **Human-readable 2-page** (`references/two-page-layout.md`) — the standing default.
  Categorized skills, grouped employer blocks, written for a person reading it.
- **ATS keyword** (`references/ats-keyword-template.md`) — deliberately plain, built so the
  recruiter's boolean search actually surfaces the candidate and so the application
  auto-loader parses every field. Uses the posting's exact vocabulary, a search-hook
  headline, a flat comma list of hard skills, and a company name on every role.

## Inputs to expect

- The target position
- The target company
- The job description (full text or link)
- Optionally: tone preference, emphasis, deadline, whether a cover letter is also wanted

If any of the first three are missing, ASK before drafting. Tailoring without the JD is
wasted effort. Use the AskUserQuestion tool rather than just typing the question in chat.

The ATS template needs the **posting's literal text**, not a summary of it. If the candidate
pastes a paraphrase or a link that can't be fetched, ask for the raw text before extracting
keywords — exact-phrase matching is the entire mechanism and it fails on a paraphrase.

## Step 0: Ask which template

Every run, before anything else, ask with AskUserQuestion:

- **ATS keyword version** — keyword-optimized for the recruiter's search and the auto-loader.
- **Human-readable 2-page** — the standing format.
- **Both** — two files.

Do not assume. Do not default silently. If the candidate names the template in their request
("ATS version for this one"), that answers the question — skip the ask and proceed.

If they pick **Both**, suffix the ATS file `_ATS` so the two don't collide; a single-template
run keeps the standard file name.

If they pick the ATS template, Steps 2–5 below still apply for choosing which bullets make
the page, but `references/ats-keyword-template.md` governs headline, skills, bullet wording,
formatting, and experience-block structure, and it **overrides** any conflicting instruction
in `two-page-layout.md` or `patterns.md`.

## Step 1: Read the references

Read these into context before drafting:

- `references/master-resume.md` — the full master record of every role and every bullet.
  Pull bullets only from here. Never invent.
- `references/profile-defaults.md` — contact block, full skills inventory, education,
  selected projects, file-naming and save-location conventions.
- `references/patterns.md` — the reusable condensed entries and the tailoring playbook.
- `references/two-page-layout.md` — the default human-readable 2-page structure to mirror.
- `references/ats-keyword-template.md` — the keyword-optimized template. Read this one
  whenever the ATS version was chosen.

## Step 2: Classify the role

Decide whether the target role sits in the candidate's **primary discipline** — the function
their most recent and most detailed roles belong to (`patterns.md` names it, set during
setup).

- **In the primary discipline** → **KEEP** those roles broken out individually, for depth.
- **Adjacent or different function** → **COLLAPSE** them into Pattern A (a single
  promotion-path entry). That frees space for the earlier roles that match this JD better.

When in genuine doubt, ask before drafting.

## Step 3: Decide the depth of the secondary era

Most candidates have one earlier era rich in stories that most modern JDs don't need —
fabrication projects, conference talks, community building, field engineering. Default to
**Pattern B**, the compact version. **EXPAND** into individual project bullets only when the
JD signals that domain directly. `patterns.md` defines both shapes and lists the JD signals
that justify expanding.

## Step 4: Ask clarifying questions

Before drafting, call AskUserQuestion to cover at least:

- **IC vs. people-management** — determines whether to lead with team/manager scope or
  technical execution.
- **The two or three themes in the JD that matter most** — biases bullet selection.
- **Tools or domains in the JD to emphasize or de-emphasize.**
- **Tone** — conservative corporate vs. modern product/tech.
- **Companion deliverables** — cover letter? LinkedIn "About" rewrite?

If the JD is light or you're missing context (industry, team size, what "success in this
role" looks like, greenfield vs. rebuilding), ask one extra question rather than guessing.

## Step 5: Tailor

Mirror the JD's verbs and metrics. Re-word bullets to use the JD's language while staying
true to the master record — every claim must be traceable to `master-resume.md`. Prune the
skills section down to what the JD or its adjacent context will actually scan for, then keep
one or two cross-domain skills as differentiators. The point of the cross-domain skills is
the "interesting candidate" effect — they're the reason the resume gets pulled out of the
pile.

The 2-page profile is the default summary. Only fall back to a longer narrative profile if a
JD specifically wants one.

**If the ATS template was chosen**, this step changes shape. Follow
`references/ats-keyword-template.md`:

1. Extract the posting's exact job title, hard skills, and verb→noun keyword pairs; discard
   the fluff.
2. Land on 5–10 exact phrases and show the candidate the keyword table before drafting.
3. Run the truth gate on every phrase against `master-resume.md` — direct match, ask, or
   drop it. Never fabricate to fill a keyword.
4. Then draft, using the posting's exact wording — no synonyms, no improved phrasing.

## Step 5b: The no-fabrication gate (ATS runs especially)

Keyword optimization changes the *vocabulary* of a claim, never the claim. Before any posting
phrase enters the document, it must trace to a line in `master-resume.md`.

If a posting keyword describes work that isn't obviously the same as something in the master
record, **stop and ask** whether the two are the same thing. Don't decide the equivalence
yourself, and don't stretch a bullet to cover a keyword. Report the keywords that had no
backing and were left out — that's the candidate's interview-prep list, and it's more useful
than a padded document.

A resume that surfaces in the search and then falls apart in the screening call is worse than
one that never surfaced.

## Step 6: Build the .docx

Invoke the docx skill to produce the actual Word document. Applications take .docx and that
should remain the default output format. The docx skill knows the mechanics — margins,
ATS-safe formatting, headings.

**For the ATS template, the formatting constraints in `ats-keyword-template.md` are hard
requirements**, not style preferences: single column, black text, one standard font, no
tables, no text boxes, no headers or footers, no icons or graphics, standard section
headings, `Month YYYY – Month YYYY` dates, and a company name inside every role block. It is
supposed to look like 1995. Do not improve the design.

File naming and save location come from `references/profile-defaults.md`. Don't leave the
file in the scratchpad.

## Step 7: Present and offer iteration

After presenting the file:

- Surface the pattern choices made (primary-discipline roles broken out or collapsed;
  secondary era compact or expanded) and the reasoning.
- Call out any skills or bullets cut, and why — the candidate can request them back.
- Offer to produce the matching cover letter once they're happy with the resume.

**ATS runs additionally report:**

- The final keyword table — each exact phrase and where it landed (headline / skills /
  bullets).
- Posting keywords that had no backing in `master-resume.md` and were therefore left out.
  These are the gaps a screening call will probe.
- Any equivalence the candidate confirmed during the truth gate, so they can see what wording
  they signed off on.
- Run the Step 9 checklist in `ats-keyword-template.md` before delivering, not after.

## Step 8: Feed confirmations back

When the truth gate surfaces real experience that isn't in `master-resume.md` — the candidate
answers a question with a capability the master record never captured — offer to add it to
`master-resume.md` so the next run doesn't flag it as a gap again. **Offer; don't add
silently.** The master record is the source of truth for every future resume, and anything
written into it must be confirmed by the candidate in their own words, with any ambiguity
(which metric, in what capacity) resolved first.

## Things to never do

- Never invent or embellish — only use claims supported by `master-resume.md`. If a JD asks
  for something not in the master record, say so rather than fabricating.
- Never go past 2 pages without explicit permission.
- Never include a full street address — city and state is the norm in the contact block.
- Never pick a template on the candidate's behalf. Ask (Step 0) unless they named one.
- On ATS runs: never substitute a synonym for the posting's exact phrase, never add soft
  skills to the skills list, never invent experience to cover a keyword, and never group
  multiple roles under a single company header.

## Why this skill exists

A resume isn't a single document — it's a body of work that needs to be re-cut for each
application. The bullets in `master-resume.md` are stable; what changes is which ones make
the page, in what order, with what verbs. This skill exists so that every tailored resume
starts from the same source of truth and applies the same decision rules, rather than
re-deriving a career narrative from scratch every time.
